<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laravel</title>
</head>
<body>
    <h1 style="width: 100%; text-align: center">Backend funcionando </br> Graças a Deus!</h1>
</body>
</html><?php /**PATH C:\Users\Alexandre\Desktop\projotav4\backend\resources\views/welcome.blade.php ENDPATH**/ ?>